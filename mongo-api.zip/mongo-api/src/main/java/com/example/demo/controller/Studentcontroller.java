package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepo;

@RestController
public class Studentcontroller {
@Autowired
StudentRepo studentrepo;

@PostMapping("/add")
public String add(@RequestBody Student stu) {
	studentrepo.save(stu);
	return "success";
}
@GetMapping("/display")
public List<Student> display(){
	return studentrepo.findAll();
}
@PutMapping("/update/{sid}")
public String update(@RequestBody Student stu,@PathVariable int sid) {
	studentrepo.deleteById(sid);
	studentrepo.save(stu);
	return "updated the id"+sid;
}
@DeleteMapping("/delete/{sid}")
public String delete(@PathVariable int sid) {
	studentrepo.deleteById(sid);
	return "deleted";
}
}
